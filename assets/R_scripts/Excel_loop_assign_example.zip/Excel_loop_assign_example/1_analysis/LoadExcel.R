# Lincoln University Ecol202 Nature Journal 1: butterflies
# sub-script to load in Excel files

# created 20120530 by Jon.Sullivan@lincoln.ac.nz
# modified for blog example 20131226

# this R script is an example of how I use the functions assign() and get() to wrangle student data from lots of spreadsheets. Each spreadsheet contains multiple worksheets. It contains each student's butterfly counts from two sites. The script imports in all of the needed worksheets from all spreadsheets then combines them together into four class-wide data.frames.

library (gdata) # this package is needed for the read.xls function. Install gdata if this line doesn't work.

# this lists the file names, copied and pasted from the folder containing them. I've only included three here for this example, but usually there are 60--80 files.
files <- c ("Student01 - Ecol202_NatureJournal1_Butterflies.xlsx", "Student02 - Ecol202_NatureJournal1_Butterflies.xlsx", "Student03 - Ecol202_NatureJournal1_Butterflies.xlsx")

# loop through all files, loading each worksheet I need from each file into R
for (i in 1:length(files)){

sheet_count <- sheetCount(paste ("../0_data/student data/", files[i], sep = ""))
filename_formatted = gsub ("[ ,&\\.-]", "_", sub (".xls[x]*", "", files[i]))

# make an R object containing the second worksheet
assign (paste ("Ecol202_aboutme_", filename_formatted, sep = ""), cbind (filename_formatted, read.xls (paste ("../0_data/student data/", files[i], sep = ""), sheet = 2, stringsAsFactors = FALSE))
)
# make an R object containing the third worksheet
assign (paste ("Ecol202_site1_", filename_formatted, sep = ""), cbind (filename_formatted, read.xls (paste ("../0_data/student data/", files[i], sep = ""), sheet = 3, stringsAsFactors = FALSE))
)
# make an R object containing the fourth worksheet
assign (paste ("Ecol202_butterflycount1_", filename_formatted, sep = ""), cbind (filename_formatted, read.xls (paste ("../0_data/student data/", files[i], sep = ""), sheet = 4, stringsAsFactors = FALSE))
)
# make an R object containing the fifth worksheet
assign (paste ("Ecol202_butterflyhostplants1_", filename_formatted, sep = ""), cbind (filename_formatted, read.xls (paste ("../0_data/student data/", files[i], sep = ""), sheet = 5, stringsAsFactors = FALSE))
)
# make an R object containing the sixth worksheet
assign (paste ("Ecol202_site2_", filename_formatted, sep = ""), cbind (filename_formatted, read.xls (paste ("../0_data/student data/", files[i], sep = ""), sheet = 6, stringsAsFactors = FALSE))
)
# make an R object containing the seventh worksheet
assign (paste ("Ecol202_butterflycount2_", filename_formatted, sep = ""), cbind (filename_formatted, read.xls (paste ("../0_data/student data/", files[i], sep = ""), sheet = 7, stringsAsFactors = FALSE))
)
# make an R object containing the eigth worksheet
assign (paste ("Ecol202_butterflyhostplants2_", filename_formatted, sep = ""), cbind (filename_formatted, read.xls (paste ("../0_data/student data/", files[i], sep = ""), sheet = 8, stringsAsFactors = FALSE))
)


}
ls () # lists the objects now in R

# now create a single spreadsheet for all site information from the class

# first, create lists of the names of all the data.frames needing to be merged
List_Ecol202_site1 <- ls (pattern = "Ecol202_site1_.+")
List_Ecol202_site2 <- ls (pattern = "Ecol202_site2_.+")
List_Ecol202_aboutme <- ls (pattern = "Ecol202_aboutme_.+")

# create a new data.frame to contain the new data, called Ecol202_sites. Fill the first row with data from the first data.frame listed. Note that I'm mixing content from two worksheets here.
Ecol202_sites <- data.frame (ID = get (List_Ecol202_site1 [1])[1,1], Site = 1, Site_name = get (List_Ecol202_site1 [1])[1,3], Co_observer = get (List_Ecol202_site1 [1])[2,3], Latitude = get (List_Ecol202_site1 [1])[3,3], Longitude = get (List_Ecol202_site1 [1])[4,3], Coordinate_source = get (List_Ecol202_site1 [1])[5,3], radius_m = get (List_Ecol202_site1 [1])[6,3], Region = get (List_Ecol202_site1 [1])[7,3], Simple_habitat_category = get (List_Ecol202_site1 [1])[8,3], Most_common_habitat_type = get (List_Ecol202_site1 [1])[9,3], Second_most_common = get (List_Ecol202_site1 [1])[10,3], Third_most_common = get (List_Ecol202_site1 [1])[11,3], Habitat_notes = get (List_Ecol202_site1 [1])[12,3], 
Student_Lincoln_ID = get (List_Ecol202_aboutme [1])[1,3],
Student_name = get (List_Ecol202_aboutme [1])[2,3],
My_butterfly_identification_expertise = get (List_Ecol202_aboutme [1])[3,3])

# create an equivalent data.frame for the data from the second site's data in each worksheet. This data.frame is called Ecol202_sites_temp2, temp becuase I won't keep it after it's been combined with Ecol202_sites.
Ecol202_sites_temp2 <- data.frame (ID = get (List_Ecol202_site2 [1])[1,1], Site = 2, Site_name = get (List_Ecol202_site2 [1])[1,3], Co_observer = get (List_Ecol202_site2 [1])[2,3], Latitude = get (List_Ecol202_site2 [1])[3,3], Longitude = get (List_Ecol202_site2 [1])[4,3], Coordinate_source = get (List_Ecol202_site2 [1])[5,3], radius_m = get (List_Ecol202_site2 [1])[6,3], Region = get (List_Ecol202_site2 [1])[7,3], Simple_habitat_category = get (List_Ecol202_site2 [1])[8,3], Most_common_habitat_type = get (List_Ecol202_site2 [1])[9,3], Second_most_common = get (List_Ecol202_site2 [1])[10,3], Third_most_common = get (List_Ecol202_site2 [1])[11,3], Habitat_notes = get (List_Ecol202_site2 [1])[12,3], 
Student_Lincoln_ID = get (List_Ecol202_aboutme [1])[1,3],
Student_name = get (List_Ecol202_aboutme [1])[2,3],My_butterfly_identification_expertise = get (List_Ecol202_aboutme [1])[3,3])

# row bind the data from the first and second sites for this first worksheet
Ecol202_sites <- rbind (Ecol202_sites, Ecol202_sites_temp2)

# now loop through and do this for all remaining Excel worksheets.
for (i in 2:length (List_Ecol202_site1)){

Ecol202_sites_temp1 <- data.frame (ID = get (List_Ecol202_site1 [i])[1,1], Site = 1, Site_name = get (List_Ecol202_site1 [i])[1,3], Co_observer = get (List_Ecol202_site1 [i])[2,3], Latitude = get (List_Ecol202_site1 [i])[3,3], Longitude = get (List_Ecol202_site1 [i])[4,3], Coordinate_source = get (List_Ecol202_site1 [i])[5,3], radius_m = get (List_Ecol202_site1 [i])[6,3], Region = get (List_Ecol202_site1 [i])[7,3], Simple_habitat_category = get (List_Ecol202_site1 [i])[8,3], Most_common_habitat_type = get (List_Ecol202_site1 [i])[9,3], Second_most_common = get (List_Ecol202_site1 [i])[10,3], Third_most_common = get (List_Ecol202_site1 [i])[11,3], Habitat_notes = get (List_Ecol202_site1 [i])[12,3], Student_Lincoln_ID = get (List_Ecol202_aboutme [i])[1,3],
Student_name = get (List_Ecol202_aboutme [i])[2,3],
My_butterfly_identification_expertise = get (List_Ecol202_aboutme [i])[3,3])Ecol202_sites_temp2 <- data.frame (ID = get (List_Ecol202_site2 [i])[1,1], Site = 2, Site_name = get (List_Ecol202_site2 [i])[1,3], Co_observer = get (List_Ecol202_site2 [i])[2,3], Latitude = get (List_Ecol202_site2 [i])[3,3], Longitude = get (List_Ecol202_site2 [i])[4,3], Coordinate_source = get (List_Ecol202_site2 [i])[5,3], radius_m = get (List_Ecol202_site2 [i])[6,3], Region = get (List_Ecol202_site2 [i])[7,3], Simple_habitat_category = get (List_Ecol202_site2 [i])[8,3], Most_common_habitat_type = get (List_Ecol202_site2 [i])[9,3], Second_most_common = get (List_Ecol202_site2 [i])[10,3], Third_most_common = get (List_Ecol202_site2 [i])[11,3], Habitat_notes = get (List_Ecol202_site2 [i])[12,3], Student_Lincoln_ID = get (List_Ecol202_aboutme [i])[1,3],
Student_name = get (List_Ecol202_aboutme [i])[2,3],
My_butterfly_identification_expertise = get (List_Ecol202_aboutme [i])[3,3])

	Ecol202_sites <- rbind (Ecol202_sites, Ecol202_sites_temp1, Ecol202_sites_temp2)

	}

# check the first and last rows of the new data.frame to check that it worked.
head (Ecol202_sites)
tail (Ecol202_sites)

# remove the intermediate steps, no longer needed
rm (list = List_Ecol202_site1)
rm (list = List_Ecol202_site2)


# now I repeat this approach for the site information.
List_Ecol202_butterflycount1 <- ls (pattern = "Ecol202_butterflycount1_.+")
List_Ecol202_butterflycount2 <- ls (pattern = "Ecol202_butterflycount2_.+")

Ecol202_butterfly_siteinfo <- data.frame (ID = get (List_Ecol202_butterflycount1 [1])[1,1], 
Site = 1, 
Start_date = get (List_Ecol202_butterflycount1 [1])[1,3], 
Start_time = get (List_Ecol202_butterflycount1 [1])[2,3], 
Temperature = get (List_Ecol202_butterflycount1 [1])[3,3], 
Wind = get (List_Ecol202_butterflycount1 [1])[4,3],
Sun = get (List_Ecol202_butterflycount1 [1])[5,3],
PrecipitationType = get (List_Ecol202_butterflycount1 [1])[6,3],
PrecipitationValue = get (List_Ecol202_butterflycount1 [1])[7,3],
SiteNotes = get (List_Ecol202_butterflycount1 [1])[8,3])

Ecol202_butterfly_siteinfo_temp2 <- data.frame (ID = get (List_Ecol202_butterflycount2 [1])[1,1], Site = 2, Start_date = get (List_Ecol202_butterflycount2 [1])[1,3], Start_time = get (List_Ecol202_butterflycount2 [1])[2,3], Temperature = get (List_Ecol202_butterflycount2 [1])[3,3], Wind = get (List_Ecol202_butterflycount2 [1])[4,3],Sun = get (List_Ecol202_butterflycount2 [1])[5,3],PrecipitationType = get (List_Ecol202_butterflycount2 [1])[6,3],PrecipitationValue = get (List_Ecol202_butterflycount2 [1])[7,3],SiteNotes = get (List_Ecol202_butterflycount2 [1])[8,3])

Ecol202_butterfly_siteinfo <- rbind (Ecol202_butterfly_siteinfo, Ecol202_butterfly_siteinfo_temp2)

butterfly_rows1 <- nrow (get (List_Ecol202_butterflycount1 [1]))

Ecol202_butterfly_speciesentry <- data.frame (ID = get (List_Ecol202_butterflycount1 [1])[4: butterfly_rows1,1], 
Site = 1, 
butterfly_species = get (List_Ecol202_butterflycount1 [1])[4:butterfly_rows1,5], 
butterfly_IDcertainty = get (List_Ecol202_butterflycount1 [1])[4:butterfly_rows1,6], 
butterfly_lifestage = get (List_Ecol202_butterflycount1 [1])[4:butterfly_rows1,7], 
butterfly_CountLess10m_min = get (List_Ecol202_butterflycount1 [1])[4:butterfly_rows1,8], 
butterfly_CountLess10m_obs = get (List_Ecol202_butterflycount1 [1])[4:butterfly_rows1,9],
butterfly_CountLess10m_max = get (List_Ecol202_butterflycount1 [1])[4:butterfly_rows1,10], 
butterfly_CountGreater10m_min = get (List_Ecol202_butterflycount1 [1])[4:butterfly_rows1,11],
butterfly_CountGreater10m_obs = get (List_Ecol202_butterflycount1 [1])[4:butterfly_rows1,12],
butterfly_CountGreater10m_max = get (List_Ecol202_butterflycount1 [1])[4:butterfly_rows1,13], 
butterfly_ActivityFlying = get (List_Ecol202_butterflycount1 [1])[4:butterfly_rows1,14],
butterfly_ActivityOnFlower = get (List_Ecol202_butterflycount1 [1])[4:butterfly_rows1,15],
butterfly_ActivityResting = get (List_Ecol202_butterflycount1 [1])[4:butterfly_rows1,16], 
butterfly_ActivityMating = get (List_Ecol202_butterflycount1 [1])[4:butterfly_rows1,17],
butterfly_ActivityDead = get (List_Ecol202_butterflycount1 [1])[4:butterfly_rows1,18],
butterfly_Comment = get (List_Ecol202_butterflycount1 [1])[4:butterfly_rows1,19])

butterfly_rows2 <- nrow (get (List_Ecol202_butterflycount2 [1]))

Ecol202_butterfly_speciesentry_temp2 <- data.frame (ID = get (List_Ecol202_butterflycount2 [1])[4: butterfly_rows2,1], 
Site = 2, butterfly_species = get (List_Ecol202_butterflycount2 [1])[4:butterfly_rows2,5], butterfly_IDcertainty = get (List_Ecol202_butterflycount2 [1])[4:butterfly_rows2,6], butterfly_lifestage = get (List_Ecol202_butterflycount2 [1])[4:butterfly_rows2,7], butterfly_CountLess10m_min = get (List_Ecol202_butterflycount2 [1])[4:butterfly_rows2,8], butterfly_CountLess10m_obs = get (List_Ecol202_butterflycount2 [1])[4:butterfly_rows2,9],butterfly_CountLess10m_max = get (List_Ecol202_butterflycount2 [1])[4:butterfly_rows2,10], butterfly_CountGreater10m_min = get (List_Ecol202_butterflycount2 [1])[4:butterfly_rows2,11],butterfly_CountGreater10m_obs = get (List_Ecol202_butterflycount2 [1])[4:butterfly_rows2,12],butterfly_CountGreater10m_max = get (List_Ecol202_butterflycount2 [1])[4:butterfly_rows2,13], butterfly_ActivityFlying = get (List_Ecol202_butterflycount2 [1])[4:butterfly_rows2,14],butterfly_ActivityOnFlower = get (List_Ecol202_butterflycount2 [1])[4:butterfly_rows2,15],butterfly_ActivityResting = get (List_Ecol202_butterflycount2 [1])[4:butterfly_rows2,16], butterfly_ActivityMating = get (List_Ecol202_butterflycount2 [1])[4:butterfly_rows2,17],butterfly_ActivityDead = get (List_Ecol202_butterflycount2 [1])[4:butterfly_rows2,18],butterfly_Comment = get (List_Ecol202_butterflycount2 [1])[4:butterfly_rows2,19])

Ecol202_butterfly_speciesentry <- rbind (Ecol202_butterfly_speciesentry, Ecol202_butterfly_speciesentry_temp2)

for (i in 2:length (List_Ecol202_butterflycount1)){
print (i)
Ecol202_butterfly_siteinfo_temp1 <- data.frame (ID = get (List_Ecol202_butterflycount1 [i])[1,1], Site = 1, Start_date = get (List_Ecol202_butterflycount1 [i])[1,3], Start_time = get (List_Ecol202_butterflycount1 [i])[2,3], Temperature = get (List_Ecol202_butterflycount1 [i])[3,3], Wind = get (List_Ecol202_butterflycount1 [i])[4,3],Sun = get (List_Ecol202_butterflycount1 [i])[5,3],PrecipitationType = get (List_Ecol202_butterflycount1 [i])[6,3],PrecipitationValue = get (List_Ecol202_butterflycount1 [i])[7,3],SiteNotes = get (List_Ecol202_butterflycount1 [i])[8,3])Ecol202_butterfly_siteinfo_temp2 <- data.frame (ID = get (List_Ecol202_butterflycount2 [i])[1,1], Site = 2, Start_date = get (List_Ecol202_butterflycount2 [i])[1,3], Start_time = get (List_Ecol202_butterflycount2 [i])[2,3], Temperature = get (List_Ecol202_butterflycount2 [i])[3,3], Wind = get (List_Ecol202_butterflycount2 [i])[4,3],Sun = get (List_Ecol202_butterflycount2 [i])[5,3],PrecipitationType = get (List_Ecol202_butterflycount2 [i])[6,3],PrecipitationValue = get (List_Ecol202_butterflycount2 [i])[7,3],SiteNotes = get (List_Ecol202_butterflycount2 [i])[8,3])

Ecol202_butterfly_siteinfo <- rbind (Ecol202_butterfly_siteinfo, Ecol202_butterfly_siteinfo_temp1, Ecol202_butterfly_siteinfo_temp2)

butterfly_rows1 <- nrow (get (List_Ecol202_butterflycount1 [i]))Ecol202_butterfly_speciesentry_temp1 <- data.frame (ID = get (List_Ecol202_butterflycount1 [i])[4: butterfly_rows1,1], 
Site = 1, butterfly_species = get (List_Ecol202_butterflycount1 [i])[4:butterfly_rows1,5], butterfly_IDcertainty = get (List_Ecol202_butterflycount1 [i])[4:butterfly_rows1,6], butterfly_lifestage = get (List_Ecol202_butterflycount1 [i])[4:butterfly_rows1,7], butterfly_CountLess10m_min = get (List_Ecol202_butterflycount1 [i])[4:butterfly_rows1,8], butterfly_CountLess10m_obs = get (List_Ecol202_butterflycount1 [i])[4:butterfly_rows1,9],butterfly_CountLess10m_max = get (List_Ecol202_butterflycount1 [i])[4:butterfly_rows1,10], butterfly_CountGreater10m_min = get (List_Ecol202_butterflycount1 [i])[4:butterfly_rows1,11],butterfly_CountGreater10m_obs = get (List_Ecol202_butterflycount1 [i])[4:butterfly_rows1,12],butterfly_CountGreater10m_max = get (List_Ecol202_butterflycount1 [i])[4:butterfly_rows1,13], butterfly_ActivityFlying = get (List_Ecol202_butterflycount1 [i])[4:butterfly_rows1,14],butterfly_ActivityOnFlower = get (List_Ecol202_butterflycount1 [i])[4:butterfly_rows1,15],butterfly_ActivityResting = get (List_Ecol202_butterflycount1 [i])[4:butterfly_rows1,16], butterfly_ActivityMating = get (List_Ecol202_butterflycount1 [i])[4:butterfly_rows1,17],butterfly_ActivityDead = get (List_Ecol202_butterflycount1 [i])[4:butterfly_rows1,18],butterfly_Comment = get (List_Ecol202_butterflycount1 [i])[4:butterfly_rows1,19])butterfly_rows2 <- nrow (get (List_Ecol202_butterflycount2 [i]))Ecol202_butterfly_speciesentry_temp2 <- data.frame (ID = get (List_Ecol202_butterflycount2 [i])[4: butterfly_rows2,1], 
Site = 2, butterfly_species = get (List_Ecol202_butterflycount2 [i])[4:butterfly_rows2,5], butterfly_IDcertainty = get (List_Ecol202_butterflycount2 [i])[4:butterfly_rows2,6], butterfly_lifestage = get (List_Ecol202_butterflycount2 [i])[4:butterfly_rows2,7], butterfly_CountLess10m_min = get (List_Ecol202_butterflycount2 [i])[4:butterfly_rows2,8], butterfly_CountLess10m_obs = get (List_Ecol202_butterflycount2 [i])[4:butterfly_rows2,9],butterfly_CountLess10m_max = get (List_Ecol202_butterflycount2 [i])[4:butterfly_rows2,10], butterfly_CountGreater10m_min = get (List_Ecol202_butterflycount2 [i])[4:butterfly_rows2,11],butterfly_CountGreater10m_obs = get (List_Ecol202_butterflycount2 [i])[4:butterfly_rows2,12],butterfly_CountGreater10m_max = get (List_Ecol202_butterflycount2 [i])[4:butterfly_rows2,13], butterfly_ActivityFlying = get (List_Ecol202_butterflycount2 [i])[4:butterfly_rows2,14],butterfly_ActivityOnFlower = get (List_Ecol202_butterflycount2 [i])[4:butterfly_rows2,15],butterfly_ActivityResting = get (List_Ecol202_butterflycount2 [i])[4:butterfly_rows2,16], butterfly_ActivityMating = get (List_Ecol202_butterflycount2 [i])[4:butterfly_rows2,17],butterfly_ActivityDead = get (List_Ecol202_butterflycount2 [i])[4:butterfly_rows2,18],butterfly_Comment = get (List_Ecol202_butterflycount2 [i])[4:butterfly_rows2,19])

	Ecol202_butterfly_speciesentry <- rbind (Ecol202_butterfly_speciesentry, Ecol202_butterfly_speciesentry_temp1, Ecol202_butterfly_speciesentry_temp2)

	}
	
head (Ecol202_butterfly_siteinfo)
head (Ecol202_butterfly_speciesentry)

# remove the rows from Ecol202_butterfly_speciesentry that don't correspond to butterfly data, such as the line with the note saying "(Add more rows if required)".
Ecol202_butterfly_speciesentry <- Ecol202_butterfly_speciesentry [!is.na(Ecol202_butterfly_speciesentry$butterfly_species) & Ecol202_butterfly_speciesentry$butterfly_species != "" & Ecol202_butterfly_speciesentry$butterfly_species != "[Add additional species if needed.]" & Ecol202_butterfly_speciesentry$butterfly_species != "(Add more rows if required)", ]
Ecol202_butterfly_speciesentry$butterfly_species <- factor (Ecol202_butterfly_speciesentry$butterfly_species)

rm (List_Ecol202_butterflycount1)
rm (List_Ecol202_butterflycount2)


# create a single spreadsheet for all host plant information from the classList_Ecol202_butterflyhostplants1 <- ls (pattern = "Ecol202_butterflyhostplants1_.+")List_Ecol202_butterflyhostplants2 <- ls (pattern = "Ecol202_butterflyhostplants2_.+")hostplantrows1 <- nrow (get (List_Ecol202_butterflyhostplants1 [1]))

# because some students recorded no host plants, I have brought in the column heading rows in this loop then remove them afterwardsEcol202_hostplants <- data.frame (ID = get (List_Ecol202_butterflyhostplants1 [1])[1:hostplantrows1,1], Site = 1, 
Plant_species = get (List_Ecol202_butterflyhostplants1 [1])[1:hostplantrows1,2], Abundance = get (List_Ecol202_butterflyhostplants1 [1])[1:hostplantrows1,3], Hostplant_or_flower = get (List_Ecol202_butterflyhostplants1 [1])[1:hostplantrows1,4], Comments = get (List_Ecol202_butterflyhostplants1 [1])[1:hostplantrows1,5], Photo_names = get (List_Ecol202_butterflyhostplants1 [1])[1:hostplantrows1,6]) hostplantrows2 <- nrow (get (List_Ecol202_butterflyhostplants2 [1]))Ecol202_hostplants_temp2 <- data.frame (ID = get (List_Ecol202_butterflyhostplants2 [1])[1:hostplantrows1,1], Site = 2, 
Plant_species = get (List_Ecol202_butterflyhostplants2 [1])[1:hostplantrows1,2], Abundance = get (List_Ecol202_butterflyhostplants2 [1])[1:hostplantrows1,3], Hostplant_or_flower = get (List_Ecol202_butterflyhostplants2 [1])[1:hostplantrows1,4], Comments = get (List_Ecol202_butterflyhostplants2 [1])[1:hostplantrows1,5], Photo_names = get (List_Ecol202_butterflyhostplants2 [1])[1:hostplantrows1,6]) Ecol202_hostplants <- rbind (Ecol202_hostplants, Ecol202_hostplants_temp2)

for (i in 2:length (List_Ecol202_butterflyhostplants1)){

hostplantrows1 <- nrow (get (List_Ecol202_butterflyhostplants1 [i]))Ecol202_hostplants_temp1 <- data.frame (ID = get (List_Ecol202_butterflyhostplants1 [i])[1:hostplantrows1,1], Site = 1, 
Plant_species = get (List_Ecol202_butterflyhostplants1 [i])[1:hostplantrows1,2], Abundance = get (List_Ecol202_butterflyhostplants1 [i])[1:hostplantrows1,3], Hostplant_or_flower = get (List_Ecol202_butterflyhostplants1 [i])[1:hostplantrows1,4], Comments = get (List_Ecol202_butterflyhostplants1 [i])[1:hostplantrows1,5], Photo_names = get (List_Ecol202_butterflyhostplants1 [i])[1:hostplantrows1,6]) hostplantrows2 <- nrow (get (List_Ecol202_butterflyhostplants2 [i]))Ecol202_hostplants_temp2 <- data.frame (ID = get (List_Ecol202_butterflyhostplants2 [i])[1:hostplantrows1,1], Site = 2, 
Plant_species = get (List_Ecol202_butterflyhostplants2 [i])[1:hostplantrows1,2], Abundance = get (List_Ecol202_butterflyhostplants2 [i])[1:hostplantrows1,3], Hostplant_or_flower = get (List_Ecol202_butterflyhostplants2 [i])[1:hostplantrows1,4], Comments = get (List_Ecol202_butterflyhostplants2 [i])[1:hostplantrows1,5], Photo_names = get (List_Ecol202_butterflyhostplants2 [i])[1:hostplantrows1,6]) Ecol202_hostplants <- rbind (Ecol202_hostplants, Ecol202_hostplants_temp1, Ecol202_hostplants_temp2)
	
}	

head (Ecol202_hostplants)

# delete rows with column headings and blank species
Ecol202_hostplants <- Ecol202_hostplants [!is.na(Ecol202_hostplants$Plant_species) & Ecol202_hostplants$Plant_species != "" & Ecol202_hostplants$Plant_species != "Plant observations:" & Ecol202_hostplants$Plant_species != "Plant species" & Ecol202_hostplants$Plant_species != "(Use drop-down list of larval food plants or type in new species)", ]

# clean up R, removing all objects with "temp" or "List" in their names
rm ( list = ls (pattern = ".+temp$") )
rm ( list = ls (pattern = "^List.+") )

ls()

# save all the results for use by the analysis and graphing scripts (not provided in this example)

write.csv (Ecol202_sites, file = "../2_results/Ecol202_NJ1_sites.csv", row.names = FALSE)
write.csv (Ecol202_butterfly_siteinfo, file = "../2_results/Ecol202_NJ1_butterfly_siteinfo.csv", row.names = FALSE)
write.csv (Ecol202_butterfly_speciesentry, file = "../2_results/Ecol202_NJ1_butterfly_speciesentry.csv", row.names = FALSE)
write.csv (Ecol202_hostplants, file = "../2_results/Ecol202_NJ1_Ecol202_hostplants.csv", row.names = FALSE)

save (Ecol202_sites, file = "../2_results/Ecol202_sites.RData")
save (Ecol202_butterfly_siteinfo, file = "../2_results/Ecol202_butterfly_siteinfo.RData")
save (Ecol202_butterfly_speciesentry, file = "../2_results/Ecol202_butterfly_speciesentry.RData")
save (Ecol202_hostplants, file = "../2_results/Ecol202_hostplants.RData")

