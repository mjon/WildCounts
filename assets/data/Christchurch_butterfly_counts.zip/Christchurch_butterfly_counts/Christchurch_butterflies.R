# butterfly summary count count data from the flat lowlands of Christchurch (i.e., excluding the Port Hills) and out to the Canterbury Plains around Lincoln
# data from Jon.Sullivan@lincoln.ac.nz

# counts from between 2003 and 2013

# note that only the summary data are included here, and only includes a subset of the available data since much of it is still in untranslated shorthand field code. All data are from per site predetermined counts of all butterflies.

load ("butterfly_species.RData")

total_butterflies <- sum (butterfly_species$total_count)

butterfly_species$proportion <- butterfly_species$total_count / sum (butterfly_species$total_count)

# set radius for the biggest circle with all species in graph
circle_radius <- 2 # inch

# calculate the area of a circle for each species where the area is proportionate to a species' abundance
butterfly_species$circle_area <- butterfly_species$proportion*(pi*circle_radius ^2)
# calculate the radius of each circle for plotting
butterfly_species$circle_radius <- sqrt (butterfly_species$circle_area / pi)

# make a figure with each species a circle of area proportional to its relative abundance.
# I make each circle with the symbols function and position it a coordinates of my choice

pdf (file = "butterfly_circles.pdf", width = 8, height = (13/16*8))
op <- par (bg = "black") # axes = FALSE not needed with a black background

plot (0,0, xlim = c(-8,8), ylim=c(-5,8), xlab = "", ylab = "")

mtext (side = 3, "Butterflies of lower Christchurch and Lincoln, New Zealand", col = "white", cex = 1.2, font = 2)

text (3.8, 6, "Recently arrived:", adj = 0, col = "white", font = 2)

b = "Pieris rapae rapae"
symbols (x = -2.5, y = 1, circles = 1, inches = butterfly_species$circle_radius[butterfly_species$Taxon == b], ann = F, bg=butterfly_species$colour[butterfly_species$Taxon == b], fg=NULL, add = TRUE)

points (4.5, 5, pch = 15, col = butterfly_species$colour[butterfly_species$Taxon == b], cex = 5)
text (5.3, 5, "Cabbage white", adj = 0, col = "white")

b = "Danaus plexippus"
symbols (x = -1.9, y = -1.4, circles = 1, inches = butterfly_species$circle_radius[butterfly_species$Taxon == b], ann = F, bg=butterfly_species$colour[butterfly_species$Taxon == b], fg=NULL, add = TRUE)

points (4.5, 4, pch = 15, col = butterfly_species$colour[butterfly_species$Taxon == b], cex = 5)
text (5.3, 4, "Monarch", adj = 0, col = "white")

b = "Vanessa itea"
symbols (x = 0.4, y = 1.9, circles = 1, inches = butterfly_species$circle_radius[butterfly_species$Taxon == b], ann = F, bg=butterfly_species$colour[butterfly_species$Taxon == b], fg=NULL, add = TRUE)

points (4.5, 3, pch = 15, col = butterfly_species$colour[butterfly_species$Taxon == b], cex = 5)
text (5.3, 3, "Yellow admiral", adj = 0, col = "white")


text (3.8, 1, "NZ endemic:", adj = 0, col = "white", font = 2)

b = "Vanessa gonerilla gonerilla"
symbols (x = -1.6, y = 4, circles = 1, inches = butterfly_species$circle_radius[butterfly_species$Taxon == b], ann = F, bg=butterfly_species$colour[butterfly_species$Taxon == b], fg=NULL, add = TRUE)

points (4.5, 0, pch = 15, col = butterfly_species$colour[butterfly_species$Taxon == b], cex = 5)
text (5.3, 0, "Red admiral", adj = 0, col = "white")

b = "Zizina oxleyi"
symbols (x = -4.8, y = 3, circles = 1, inches = butterfly_species$circle_radius[butterfly_species$Taxon == b], ann = F, bg=butterfly_species$colour[butterfly_species$Taxon == b], fg=NULL, add = TRUE)

points (4.5, -1, pch = 15, col = butterfly_species$colour[butterfly_species$Taxon == b], cex = 5)
text (5.3, -1, "Southern blue", adj = 0, col = "white")

b = "Lycaena spp"
symbols (x = -6.2, y = 3, circles = 1, inches = butterfly_species$circle_radius[butterfly_species$Taxon == b], ann = F, bg=butterfly_species$colour[butterfly_species$Taxon == b], fg=NULL, add = TRUE)

points (4.5, -2, pch = 15, col = butterfly_species$colour[butterfly_species$Taxon == b], cex = 5)
text (5.3, -2, "Coppers", adj = 0, col = "white")

text (1.6, -4.5, paste (total_butterflies, "butterflies counted between 2003 and 2013"), adj = 0, col = "white", cex = 0.7)
text (1.6, -5, "Counted and compiled by Jon.Sullivan@lincoln.ac.nz", adj = 0, col = "white", cex = 0.7)

par (op)
dev.off()
